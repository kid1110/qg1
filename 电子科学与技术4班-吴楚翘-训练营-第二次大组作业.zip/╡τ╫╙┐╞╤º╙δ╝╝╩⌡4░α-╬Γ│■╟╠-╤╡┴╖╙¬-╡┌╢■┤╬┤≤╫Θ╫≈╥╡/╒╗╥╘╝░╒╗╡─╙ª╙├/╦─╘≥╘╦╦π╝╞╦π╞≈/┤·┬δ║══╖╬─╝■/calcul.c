#include<stdio.h>
#include<stdlib.h>
#include "calcul.h"

int GetNum(OperateNum *StackNum){        //ȡ������ 
	return StackNum->datas[StackNum->top];
}

char GetSymbol(OperateSymbol *StackSymbol){   //ȡ����� 
	return StackSymbol->symbol[StackSymbol->top];
}

void PushOperateNum(OperateNum *StackNum,int data){
	StackNum->top++;                                          //��������ջ 
	StackNum->datas[StackNum->top]=data;                  
} 

void PushOperateSymbol(OperateSymbol *StackSymbol,char ch){
	StackSymbol->top++;
	StackSymbol->symbol[StackSymbol->top]=ch;                      //�������ջ 
} 

int PopOperateNum(OperateNum *StackNum){
	int num;
	num=StackNum->datas[StackNum->top];             //��������ջ 
	StackNum->top--;
	return num;
}

char PopOperateSymbol(OperateSymbol *StackSymbol){
	char sym;
	sym=StackSymbol->symbol[StackSymbol->top];          //�������ջ�� 
	StackSymbol->top--;
	return sym;
}

int ismbol(char ch){
	if(ch=='+'||ch=='-'||ch=='*'||ch=='/'){
		return 1;                                     //�ж������ 
	}else{
		return 0;
	}
}

char Priority(char ch1,char ch2){
	switch(ch1){
		case '+':
		case '-': if(ch2=='*'||ch2=='/'){
			return '<';
			}
			else if(ch2=='+'||ch2=='+'){
				return '>';
			}
			else{return '>';
			}
			break;
			
		case '*':
		case '/':if(ch2=='+'||ch2=='-'){
				return'>';
			}else if(ch2=='*'||ch2=='/'){
				return '>';
			}else{
				return '>';
			}
			break;
		case '\n':if(ch2=='\n'){
				return '>';
			}else{
				return '<';
			}
			break;
		}
}

void menu(){
	system("cls"); 
	printf("***********************1ʹ�ü�����*****************************\n");
	printf("***********************2�˳�����*******************************\n");
	printf("���������ʽ��\n");  
} 
	
