#include<stdio.h>
#include<stdlib.h>
#include "calcul.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	menu();
	int choice;
	char num[100];
		scanf("%d",&choice);
		choice=(char)(choice+96);
		switch(choice){
			case 'a':printf("")
				scanf("%s",num);
				break;
			case 'b':
				system("cls");
				printf("�����˳���");
				return 0;	
		}
	
	return 0;
}
