#include<stdio.h>
#include "../head/SqStack.h "
#include<stdlib.h>



//typedef struct SqStack 
//{
//	ElemType *elem;        //�洢Ԫ�� 
//	int top;               //ջ�� 
//	int size;              //ջ��С 
//} SqStack;

//typedef int ElemType;

void menu(){
	system("cls");
	printf("**********************1��ʼ��ջ*******************************\n");
	printf("**********************2�ж�ջ�Ƿ�Ϊ��*************************\n");
	printf("**********************3�õ�ջ��Ԫ��***************************\n");
	printf("**********************4���ջ*********************************\n");
	printf("**********************5�ݻ�ջ*********************************\n");
	printf("**********************6���ջ�ĳ���***************************\n");
	printf("**********************7��ջ***********************************\n");
	printf("**********************8��ջ***********************************\n");
	printf("**********************9�˳�����*******************************\n");	 
	printf("**********************���������֣�****************************\n");
  
	 
}






Status initStack(SqStack *s,int sizes){

		s->elem=(ElemType*)malloc(sizes*sizeof(ElemType));         //�����ڴ� 
		s->top=-1;
		return SUCCESS;
	
}
//��ʼ��ջ
Status isEmptyStack(SqStack *s){
	if(s->top!=-1){
			return ERROR;
		}else{
			return SUCCESS;
		}
	
}
//�ж�ջ�Ƿ�Ϊ��
Status getTopStack(SqStack *s,ElemType *e){
if(s->top==-1){
	return ERROR;
}else{
	*e = s->elem[s->top];
	return SUCCESS;
}
}
//�õ�ջ��Ԫ��
Status clearStack(SqStack *s){
	if(s->top==-1){
		return ERROR;
	}else{
		s->top=-1;
		return SUCCESS;
	}
	
}
//���ջ
Status destroyStack(SqStack *s){
   if(!s){
   	   return ERROR;
   }else{
   	free(s);
   	return SUCCESS;
   }
}
//����ջ
Status stackLength(SqStack *s,int *length){
	if(s->top==-1){
		return ERROR;
	}else{
	
		*length=s->top+1;
	}
}
//���ջ����
Status pushStack(SqStack *s,ElemType data){
	if(s->top==s->size-1){
		return ERROR;
	}
	s->top++;
	s->elem[s->top]=data;
	return SUCCESS;
}
//��ջ
Status popStack(SqStack *s,ElemType *data){
	if(s->top==-1){
		return ERROR;
	}
	*data=s->elem[s->top];
	s->top--;
	return SUCCESS;
}
//��ջ
