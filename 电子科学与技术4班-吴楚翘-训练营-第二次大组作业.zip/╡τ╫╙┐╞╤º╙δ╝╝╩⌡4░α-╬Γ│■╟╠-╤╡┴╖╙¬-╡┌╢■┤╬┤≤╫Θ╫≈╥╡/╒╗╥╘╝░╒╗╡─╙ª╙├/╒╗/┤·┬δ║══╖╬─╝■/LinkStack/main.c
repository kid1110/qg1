#include <stdio.h>
#include <stdlib.h>
#include "../head/LinkStack.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
ElemType e,length,data,num;
int main(int argc, char *argv[]) {
	restart:;
	menu();
	LinkStack *s=NULL;
	int choice, judge,num;
	while(scanf("%d",&choice) != EOF ){
		fflush(stdin);
		choice=(char)(choice+96);
		switch(choice){
			case 'a':
				s=(LinkStack*)malloc(sizeof(LinkStack));
				judge=initLStack(s);
				if(judge){
					printf("success!");
				}else{
					printf("error!");
				}
				Sleep(2000);
				menu();
				break;
			case 'b':if(!s){
				printf("Ī��ջ"); 
				}else{
				judge=isEmptyLStack(s);
				if(judge){
					printf("�ǿ�ջ"); 
				}else{
					printf("���ǿ�ջ"); 
				}
				}
				Sleep(2000);
				menu();
				break;	
			case 'c':if(!s){
					printf("Ī��");
			}else{
			judge=getTopLStack(s,&e);
					if(judge){
						printf("ջ����Ԫ��Ϊ%d",e);
					}else{
						printf("��"); 
					}
				}
				Sleep(2000);
				menu();
				break;
				
			case 'd':if(s==NULL){
				printf("��������"); 
				}else{
				judge=clearLStack(s);
				if(judge){
					printf("�����ɹ���"); 
				}else{
					printf("����ʧ�ܣ�"); 
				}
				Sleep(2000);
				menu();
				break;
				}
			case 'e':judge=destroyLStack(s);
					if(judge){
						printf("�ݻٳɹ���");
					}else{
						printf("û��ջ����ݻ�!");
						s=NULL;
					}
					Sleep(2000);
					menu();
					break;
			case 'f':if(!s){
				printf("û��ջ��");
				}else{
					judge=LStackLength(s,&length);
						if(judge){
							printf("������%d",length);
						}else{
							printf("������0");
						}
					}
					Sleep(2000);
					menu();
					break;
			case 'g':if(!s){
				printf("û��ջ��"); 
				}else{
					printf("������ֵ");
					scanf("%d",&data); 
					judge=pushLStack(s,data);
					if(judge){
						printf("success!");
					}else{
						printf("fail!");
					}
				}
				 Sleep(2000);
				 menu();
				 break;
			case 'h':if(!s){
					printf("Ī��ջ��"); 
				}else{
					judge=popLStack(s,&num);
					if(judge){
					printf("�ɹ���Ϊ%d",num);
					}else{
					printf("û�ж������Գ�����"); 
					}
				}
					Sleep(2000);
					menu();
					break;
			case 'i':
				printf("�����˳�!");
				return 0;
			default :
				printf("�������������������룡");
				Sleep(2000);
				goto restart; 
	}
	}
	
	return 0;
}
