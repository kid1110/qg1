#include<stdio.h>
#include "../head/LinkStack.h"
#include<stdlib.h>

void menu(){
	system("cls");
	printf("**********************1��ʼ����ջ*******************************\n");
	printf("**********************2�ж�ջ�Ƿ�Ϊ��*************************\n");
	printf("**********************3�õ�ջ��Ԫ��***************************\n");
	printf("**********************4���ջ*********************************\n");
	printf("**********************5�ݻ�ջ*********************************\n");
	printf("**********************6���ջ�ĳ���***************************\n");
	printf("**********************7��ջ***********************************\n");
	printf("**********************8��ջ***********************************\n");
	printf("**********************9�˳�����*******************************\n");	 
	printf("**********************���������֣�****************************\n");
  
	 
}

Status initLStack(LinkStack *s){
	
     s->top=NULL;
     s->count=0;
     return SUCCESS;
  }//��ʼ��ջ
Status isEmptyLStack(LinkStack *s){
	if(s->top==NULL){
		return SUCCESS;
	}else{
		return ERROR;
	}
}
//�ж�ջ�Ƿ�Ϊ��
Status getTopLStack(LinkStack *s,ElemType *e){
	if(s->top==NULL){
		return ERROR;
	}else{
		*e=s->top->data;
		return SUCCESS;
	}
	
}
//�õ�ջ��Ԫ��
Status clearLStack(LinkStack *s){
	LinkStackPtr q;
	while(s->top){
		q=s->top;
		s->top=q->next;
		s->count--;
		free(q);
		return SUCCESS;
	}
	
}
//���ջ
Status destroyLStack(LinkStack *s){
	if(!s){
		return ERROR;
	}else{
	LinkStackPtr q;
	while(s->top){
		q=s->top;
		s->top=q->next;
		s->count--;
		free(q);}
		free(s);
		
		return SUCCESS;
	}
}
//����ջ
Status LStackLength(LinkStack *s,int *length){
	if(s->top==NULL){
		return ERROR;
	}else{
		*length=s->count;
		return SUCCESS;
	}
}
//���ջ����

Status pushLStack(LinkStack *s,ElemType data){
      LinkStackPtr temp=(LinkStackPtr)malloc(sizeof(StackNode));
      if(temp==NULL){
      	return ERROR;
	  }
      temp->data=data;
      temp->next=s->top;
      s->top=temp;
      s->count++;
      return SUCCESS;
}
//��ջ


Status popLStack(LinkStack *s,ElemType *data){
	StackNode *p=(StackNode*)malloc(sizeof(StackNode));
	if(s->top==NULL){
		return ERROR;
	}else{
		p=s->top;
		*data=p->data;
		s->top=p->next;
		s->count--;
		free(p);
		return SUCCESS;
		
	}
	
}
//��ջ









