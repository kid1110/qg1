#include <stdio.h>
#include <stdlib.h>
#include "LQueue.h" 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
		restart:;
	int choice;
	menu();
	while(scanf("%d",&choice) !=EOF ){
    		fflush(stdin);
    		choice = (char)(choice+96);
    		switch(choice){
    			case 'a':{
    				Lrestart:;
    				int select;
    				LQueue Q;
    				Q.front = NULL;
    				 Lmenu();
					while(scanf("%d",&select) != EOF){
					 	fflush(stdin);
					 	
					 	select=(char)(select+96);
					 	int judge;
					 	switch(select){
					 		case 'a':{
							 	
					 			InitLQueue(&Q);
					 			Sleep(2000);
					 			Lmenu();
								break;
							 	}
							case 'b':{
								DestoryLQueue(&Q);
								Sleep(2000);
								Lmenu();
								break;
								}
							case 'c':{
								judge = IsEmptyLQueue(&Q);
								if(	Q.front == NULL){
										printf("��û��ʼ���أ�");
									}else{
										if(judge){
											printf("�����ǿգ�"); 
										}else{
											printf("���в��ǿյģ�"); 
										}
									} 
								Sleep(2000);
								Lmenu();
								break;
								}
							case 'd':{if(	Q.front == NULL){
									printf("��û��ʼ���أ�"); 
								}else if(IsEmptyLQueue(&Q)){
									
									printf("���Ǹ��ն��У�"); 
								}else{
									if(datatype[0] == 1){
										int e;
										GetHeadLQueue(&Q, &e);
										printf("ͷԪ��Ϊ%d",e);
									}
									if(datatype[0] == 2){
										double e;
										GetHeadLQueue(&Q, &e);
										printf("ͷԪ��Ϊ%.2lf",e);
									}
										if(datatype[0] == 3){
										char e[50];
										GetHeadLQueue(&Q, e);
										printf("ͷԪ��Ϊ%s",e);
									}
								}
								Sleep(2000);
								Lmenu();	
								break;
								}
							case 'e':{
								if(	Q.front == NULL){
									printf("��û��ʼ���أ�"); 
								}else{
									int length;
									length =  LengthLQueue(&Q);
									printf("���г���Ϊ%d",length);
								}
								Sleep(2000);
								Lmenu();
								break;
								}
							case 'f':{
								if(Q.front == NULL){
									printf("��û��ʼ���أ�");
								}else{
									judgetype(&Q);
								}
								Sleep(2000);
								Lmenu();
								break;
								}
							case 'g':{
								if(Q.front == NULL){
									printf("��û��ʼ���أ�");
								}else{
									judge = DeLQueue(&Q);
									if(judge){
										printf("�ɹ���");
									}else{
										printf("�Ѿ��ǿյ��ˣ�"); 
										}
									}
								Sleep(2000);
								Lmenu();
								break;
								}
							case 'h':{
								if(Q.front == NULL){
									printf("��û��ʼ���أ�");
								}else{
									ClearLQueue(&Q);
								}
								Sleep(2000);
								Lmenu();
								break;
								} 
							case 'i':{
								if(Q.front == NULL){
									printf("��û��ʼ���أ�");	
								}else{
									judge = TraverseLQueue(&Q, LPrint);
									if(judge == 0){
										printf("������ʲô������û�У�");
									}
								}
								Sleep(2000);
								Lmenu();
								break;
								}
							case 'j':{
								printf("���ڷ��أ�");
								Sleep(2000);
								menu(); 
								break;
							}
							default:
								printf("��������,���������룡");
								Sleep(2000);
								goto Lrestart; 
						 }
					 }
					
				}
				
				case 'b':{
					system("cls");
					printf("ϵͳ������");
					getchar();
					system("cls"); 
					printf("ƭ��ģ�");	
					return 0;
				}
				default:
					printf("�����������������");
					Sleep(2000);
					goto restart;
			}
	}
	return 0;
}
