#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include "AQueue.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	restart:;
	int choice;
	menu();
	
    
    while(scanf("%d",&choice) !=EOF ){
    		fflush(stdin);
    		choice = (char)(choice+96);
    		switch(choice){
    			case 'a':{
    				Arestart:;
    				int select;
    				AQueue Q;
    				Q.data[0] = NULL;
    				 Amenu();
					while(scanf("%d",&select) != EOF){
					 	fflush(stdin);
					 	
					 	select=(char)(select+96);
					 	int judge;
					 	switch(select){
					 		case 'a':{
							 	
					 			InitAQueue(&Q);
					 			Sleep(2000);
					 			Amenu();
								break;
							 	}
							case 'b':{
								DestoryAQueue(&Q);
								Sleep(2000);
								Amenu();
								break;
								}
							case 'c':{
								judge = IsFullAQueue(&Q);
									if(Q.data[0] == NULL){
										printf("��û��ʼ���أ�");
									}else{
										if(judge){
											printf("����������"); 
										}else{
											printf("����û��"); 
										}
									} 
								Sleep(2000);
								Amenu();
								break;
								}
							case 'd':{
								judge =IsEmptyAQueue(&Q);
								if(Q.data[0] == NULL){
										printf("��û��ʼ���أ�");
									}else{
										if(judge){
											printf("�����ѿգ�"); 
										}else{
											printf("�����ǿյģ�"); 
										}
									} 
								Sleep(2000);
								Amenu();
								break;
								}
							case 'e':{if(Q.data[0] == NULL){
									printf("��û��ʼ���أ�"); 
								}else if(IsEmptyAQueue(&Q)){
									printf("���Ǹ��ն��У�"); 
								}else{
									if(datatype[Q.front] == 1){
										int e;
										GetHeadAQueue(&Q, &e);
										printf("ͷԪ��Ϊ%d",e);
									}
									if(datatype[Q.front] == 2){
										double e;
										GetHeadAQueue(&Q, &e);
										printf("ͷԪ��Ϊ%.2lf",e);
									}
										if(datatype[Q.front] == 3){
										char e[50];
										GetHeadAQueue(&Q, e);
										printf("ͷԪ��Ϊ%s",e);
									}
								}
								Sleep(2000);
								Amenu();	
								break;
								}
							case 'f':{
								if(Q.data[0] == NULL){
									printf("��û��ʼ���أ�"); 
								}else{
									int length;
									length = LengthAQueue(&Q);
									printf("���г���Ϊ%d",length);
								}
								Sleep(2000);
								Amenu();
								break;
								}
							case 'g':{
								if(Q.data[0] == NULL){
									printf("��û��ʼ���أ�");
								}else{
									judgetype(&Q);
								}
								Sleep(2000);
								Amenu();
								break;
								}
							case 'h':{
								if(Q.data[0] == NULL){
									printf("��û��ʼ���أ�");
								}else{
									judge = DeAQueue(&Q);
									if(judge){
										printf("�ɹ���");
									}else{
										printf("�Ѿ��ǿյ��ˣ�"); 
										}
									}
								Sleep(2000);
								Amenu();
								break;
								}
							case 'i':{
								if(Q.data[0] == NULL){
									printf("��û��ʼ���أ�");
								}else{
									ClearAQueue(&Q);
								}
								Sleep(2000);
								Amenu();
								break;
								} 
							case 'j':{
								if(Q.data[0] == NULL){
									printf("��û��ʼ���أ�");	
								}else{
									judge = TraverseAQueue(&Q, APrint);
									if(judge == 0){
										printf("������ʲô������û�У�");
									}
								}
								Sleep(2000);
								Amenu();
								break;
								}
							case 'k':{
								printf("���ڷ��أ�");
								Sleep(2000);
								menu(); 
								break;
							}
							default:
								printf("��������,���������룡");
								Sleep(2000);
								goto restart; 
						 }
					 }
					
				}
				
				case 'b':{
					system("cls");
					printf("ϵͳ������");
					getchar();
					system("cls"); 
					printf("ƭ��ģ�");	
					return 0;
				}
				default:
					printf("�����������������");
					Sleep(2000);
					goto restart;
			}
	}
	return 0;
}
