#include "../head/duLinkedList.h"
#include<stdlib.h>
#include<stdio.h>

/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
   *L = (DuLinkedList)malloc(sizeof(DuLNode));
   if(!(*L)){
   	return ERROR;
}
   	(*L)->prior = NULL;
   	(*L)->next = NULL;
   	return SUCCESS;
    
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
      DuLinkedList temp;
      DuLinkedList pre;
      if(*L!=NULL){
	  temp=(*L)->next;
      while(temp!=NULL){
      	pre=temp;
      	temp=temp->next;
      	free(pre);
	  }
	  free(*L);    //	�ͷŵ�һ�����ڴ�
	  printf("has destroyed!\n"); 
}else{
	printf("noooooo!");
}
 
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
	q=(DuLinkedList)malloc(sizeof(DuLNode));
    if(p->prior==NULL){         //��p��ǰ��ΪNULL 
    	q->next=p;
    	p->prior=q;
    	return SUCCESS; 
	}else{
		q->prior=p->prior;
		p->prior->next=q;
		q->next =p;
		p->prior = q;
return SUCCESS;
		
	}
        
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {

if(p->next==NULL){
	p->next=q;
	q->prior=p;
	return SUCCESS;
}else{
    q->next=p->next;
    q->prior=p;
    p->next=q;
    q->next->prior=q;
	return SUCCESS;
}
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
     DuLinkedList t,q;
     
     if(p->next!=NULL){
     t=p->next;
     *e=t->data ;       //ץȡp��һ���ڵ������ 
     t->next->prior=p;
     p->next = t->next;
     free(t);
     return SUCCESS;
	 }else{
	 	return ERROR;
	 }
}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e)) {
   DuLinkedList s;
   s=L;
   if(s->next==NULL){
   	printf("noooooo!\n");
   }else{

   while(s->next!=NULL){
   	(*visit)(s->data);
   	s->data;
   }
}
}

