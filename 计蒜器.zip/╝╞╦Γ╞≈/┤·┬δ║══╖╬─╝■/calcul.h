#ifndef CALCUL_H
#define CALCUL_H

#include<stdbool.h>
#define _CRT_SECURE_NO_WARNINGS

typedef double ElemType;
typedef char ElemType_c;
#define STACK_INIT_SIZE	10     //ջ���ܴ洢����
#define STACKINCREMENT 10        //���ӵ�����
#define MAXBUFFER 10           //�ַ����ĳ���

typedef struct SqStack//ElemType���͵�ջ
{
	ElemType *base;//ջ��ָ��
	ElemType *top;//ջ��ָ��
	int stacksize;//ջ�ܵĿ�������
}SqStack;

typedef struct SqStack_c
{
	ElemType_c *base;
	ElemType_c *top;
	int stacksize;
}SqStack_c;








SqStack* InitStack();
SqStack_c* InitStack_c();
bool Push(SqStack *s, ElemType e);
bool Push_c(SqStack_c *s, ElemType_c e);
bool Pop(SqStack *s, ElemType *e);
bool Pop_c(SqStack_c *s, ElemType_c *e);
ElemType GetTop(SqStack *s);
ElemType_c GetTop_c(SqStack_c *s);
void ClearStack(SqStack *s);
void ClearStack_c(SqStack_c *s);
void DestroyStack(SqStack *s);
void DestroyStack_c(SqStack_c *s);
int StackLen(SqStack *s);
void DisplayStack(SqStack*s);
void DisplayStack_c(SqStack_c* s);
#endif
