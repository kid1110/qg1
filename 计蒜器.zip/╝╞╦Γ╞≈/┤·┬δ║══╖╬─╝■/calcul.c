#include<stdio.h>
#include<stdlib.h>
#include "calcul.h"
#include<stdbool.h>


//ջ�Ľ���
SqStack* InitStack()
{
	SqStack *s = (SqStack *)malloc(sizeof(SqStack));
	s->base = (ElemType *)malloc(STACK_INIT_SIZE * sizeof(ElemType));
	if (!s->base)
	{
		exit(0);
	}
	s->top = s->base;
	s->stacksize = STACK_INIT_SIZE;
	return s;
}

SqStack_c* InitStack_c()
{
	SqStack_c *s = (SqStack_c *)malloc(sizeof(SqStack_c));
	s->base = (ElemType_c *)malloc(STACK_INIT_SIZE * sizeof(ElemType_c));
	if (!s->base)
	{
		exit(0);
	}
	s->top = s->base;
	s->stacksize = STACK_INIT_SIZE;
	return s;
}

//ѹջ
bool Push(SqStack *s, ElemType e)
{
	if (s->top - s->base >= s->stacksize)
	{
		s->base = (ElemType *)realloc(s->base, (s->stacksize + STACKINCREMENT) * sizeof(ElemType)); //���ջ���ˣ�����ջ����
		if (!s->base)
		{
			return false;
		}
		s->top = s->base + s->stacksize;
		s->stacksize = s->stacksize + STACKINCREMENT;
	}
	*(s->top) = e;
	s->top++;
	return true;
}

bool Push_c(SqStack_c *s, ElemType_c e)
{
	if (s->top - s->base >= s->stacksize)
	{
		s->base = (ElemType_c *)realloc(s->base, (s->stacksize + STACKINCREMENT) * sizeof(ElemType_c)); //���ջ���ˣ�����ջ����
		if (!s->base)
		{
			return false;
		}
		s->top = s->base + s->stacksize;
		s->stacksize = s->stacksize + STACKINCREMENT;
	}
	*(s->top) = e;
	s->top++;
	return true;
}

//��ջ
bool Pop(SqStack *s, ElemType *e)
{
	if (s->top == s->base)
	{
		return false;
	}
	--(s->top);
	*e = *(s->top);
	return true;
}

bool Pop_c(SqStack_c *s, ElemType_c *e)
{
	if (s->top == s->base)
	{
		return false;
	}
	--(s->top);
	*e = *(s->top);
	return true;
}

//��ȡջ��Ԫ�أ�����ջ
ElemType GetTop(SqStack *s)
{
	ElemType e;
	if (s->top == s->base)
	{
		exit(0);
	}
	e = *(s->top - 1);
	return e;
}

ElemType_c GetTop_c(SqStack_c *s)
{
	ElemType_c e;
	if (s->top == s->base)
	{
		exit(0);
	}
	e = *(s->top - 1);
	return e;
}

//���ջ
void ClearStack(SqStack *s)
{
	s->top = s->base;
}

void ClearStack_c(SqStack_c *s)
{
	s->top = s->base;
}

//����һ��ջ
void DestroyStack(SqStack *s)
{
	int len;
	len = s->stacksize;
	if (s->base)
	{
		free(s->base);
	}
	s->base = s->top = NULL;
	s->stacksize = 0;
	free(s);
	s = NULL;
}

void DestroyStack_c(SqStack_c *s)
{
	int len;
	len = s->stacksize;
	if (s->base)
	{
		free(s->base);
	}
	s->base = s->top = NULL;
	s->stacksize = 0;
	free(s);
	s = NULL;
}

//����ջ�ĵ�ǰ��С
int StackLen(SqStack *s)
{
	return(s->top - s->base);
}

int StackLen_c(SqStack_c *s)
{
	return(s->top - s->base);
}

//��ʾջ��Ԫ��
void DisplayStack(SqStack*s)
{
	int length,i;
	ElemType *initbase = s->base;
	length = (s->top - s->base);
	for (i = 0; i < length; i++)
	{
		printf("%d ",*(s->base));
		s->base++;
	}
	printf("\n");
	s->base = initbase;
}

void DisplayStack_c(SqStack_c* s)
{
	int length,i;
	ElemType_c *initbase = s->base;
	length = (s->top - s->base);
	for (i = 0; i < length; i++)
	{
		printf("%d ",*(s->base));
		s->base++;
	}
	printf("\n");
	s->base = initbase;
}
 
